import { useState, useRef, useEffect } from "react";
import { Mail, Lock, ArrowRight, X } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

export default function SignInCard() {
    const { openSignUp, closeAuth } = useAuth();
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [touched, setTouched] = useState({ email: false, password: false });
    
    const emailRef = useRef(null);

    useEffect(() => {
        emailRef.current?.focus();
    }, []);

    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    const isPasswordValid = password.length > 0;
    const isFormValid = isEmailValid && isPasswordValid;

    const handleSubmit = (e) => {
        e.preventDefault();
        if (isFormValid) {
            console.log("Signing in...", { email, password });
            closeAuth();
        }
    };

    return (
        <div className="w-full max-w-[440px] bg-[#0c0c0c]/90 backdrop-blur-2xl border border-white/10 rounded-[24px] shadow-[0_30px_80px_rgba(0,0,0,0.8)] p-8 relative overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[200px] bg-[#FF9D00]/10 blur-[80px] pointer-events-none rounded-full" />
            
            <button 
                onClick={closeAuth}
                className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors duration-200 z-10"
                aria-label="Close"
            >
                <X className="w-5 h-5" />
            </button>

            <div className="relative z-10">
                <div className="mb-8">
                    <h2 className="text-[28px] font-bold text-white mb-2">Welcome back</h2>
                    <p className="text-white/50 text-[15px]">Enter your credentials to access NimbusOps.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="space-y-1.5">
                        <label className="text-[13px] font-medium text-white/80 ml-1 block">Email address</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <Mail className={`w-4 h-4 ${touched.email && !isEmailValid ? 'text-red-400' : 'text-white/40'}`} />
                            </div>
                            <input
                                ref={emailRef}
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                onBlur={() => setTouched({ ...touched, email: true })}
                                className={`w-full bg-white/5 border ${touched.email && !isEmailValid ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-[#FF9D00]/50'} rounded-xl py-2.5 pl-10 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:ring-1 ${touched.email && !isEmailValid ? 'focus:ring-red-500' : 'focus:ring-[#FF9D00]/50'} transition-all`}
                                placeholder="name@company.com"
                            />
                        </div>
                        {touched.email && !isEmailValid && (
                            <p className="text-red-400 text-[12px] ml-1 mt-1">Please enter a valid email address.</p>
                        )}
                    </div>

                    <div className="space-y-1.5">
                        <div className="flex items-center justify-between ml-1">
                            <label className="text-[13px] font-medium text-white/80 block">Password</label>
                            <a href="#" className="text-[12px] text-[#FF9D00] hover:text-[#FF9D00]/80 transition-colors">Forgot password?</a>
                        </div>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <Lock className="w-4 h-4 text-white/40" />
                            </div>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                onBlur={() => setTouched({ ...touched, password: true })}
                                className="w-full bg-white/5 border border-white/10 rounded-xl py-2.5 pl-10 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:border-[#FF9D00]/50 focus:ring-1 focus:ring-[#FF9D00]/50 transition-all"
                                placeholder="••••••••"
                            />
                        </div>
                    </div>

                    <div className="flex items-center gap-2 ml-1">
                        <input type="checkbox" id="remember" className="w-4 h-4 rounded bg-white/5 border-white/10 accent-[#FF9D00] cursor-pointer" />
                        <label htmlFor="remember" className="text-[13px] text-white/60 cursor-pointer select-none">Remember me for 30 days</label>
                    </div>

                    <button
                        type="submit"
                        disabled={!isFormValid}
                        className={`w-full group flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-all duration-300 ${
                            isFormValid 
                            ? 'bg-white text-black hover:bg-[#FF9D00] hover:scale-[1.02]' 
                            : 'bg-white/10 text-white/30 cursor-not-allowed'
                        }`}
                    >
                        <span>Sign In</span>
                        <ArrowRight className={`w-4 h-4 transition-transform duration-300 ${isFormValid ? 'group-hover:translate-x-1' : ''}`} />
                    </button>
                    
                    <div className="relative flex items-center justify-center my-6">
                        <div className="absolute w-full h-[1px] bg-white/10" />
                        <span className="relative z-10 bg-[#0c0c0c] px-4 text-[12px] text-white/40 uppercase tracking-widest">Or continue with</span>
                    </div>

                    <button
                        type="button"
                        className="w-full flex items-center justify-center gap-3 py-3 rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-colors duration-200"
                    >
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                        </svg>
                        <span className="text-[14px] font-medium">Google</span>
                    </button>
                </form>

                <p className="mt-8 text-center text-[14px] text-white/50">
                    Don't have an account?{' '}
                    <button onClick={openSignUp} className="text-[#FF9D00] hover:text-[#FF9D00]/80 font-medium transition-colors">
                        Create Account
                    </button>
                </p>
            </div>
        </div>
    );
}
