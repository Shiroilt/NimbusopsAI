import { useState, useRef, useEffect } from "react";
import { Mail, Lock, User, ArrowRight, X } from "lucide-react";
import { useAuth } from "../../context/AuthContext";

export default function SignUpCard() {
    const { openSignIn, closeAuth } = useAuth();
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [touched, setTouched] = useState({ name: false, email: false, password: false, confirmPassword: false });
    
    const nameRef = useRef(null);

    useEffect(() => {
        nameRef.current?.focus();
    }, []);

    const isNameValid = name.trim().length > 1;
    const isEmailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    const isPasswordValid = password.length >= 8;
    const isConfirmPasswordValid = confirmPassword === password && confirmPassword.length > 0;
    const isFormValid = isNameValid && isEmailValid && isPasswordValid && isConfirmPasswordValid;

    const handleSubmit = (e) => {
        e.preventDefault();
        if (isFormValid) {
            console.log("Creating account...", { name, email, password });
            closeAuth();
        }
    };

    return (
        <div className="w-full max-w-[440px] bg-[#0c0c0c]/90 backdrop-blur-2xl border border-white/10 rounded-[24px] shadow-[0_30px_80px_rgba(0,0,0,0.8)] p-8 relative overflow-hidden">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[200px] bg-[#FF9D00]/10 blur-[80px] pointer-events-none rounded-full" />
            
            <button 
                onClick={closeAuth}
                className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors duration-200 z-10"
                aria-label="Close"
            >
                <X className="w-5 h-5" />
            </button>

            <div className="relative z-10">
                <div className="mb-8">
                    <h2 className="text-[28px] font-bold text-white mb-2">Create Account</h2>
                    <p className="text-white/50 text-[15px]">Join NimbusOps and orchestrate your infrastructure.</p>
                </div>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-1.5">
                        <label className="text-[13px] font-medium text-white/80 ml-1 block">Full Name</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <User className={`w-4 h-4 ${touched.name && !isNameValid ? 'text-red-400' : 'text-white/40'}`} />
                            </div>
                            <input
                                ref={nameRef}
                                type="text"
                                value={name}
                                onChange={(e) => setName(e.target.value)}
                                onBlur={() => setTouched({ ...touched, name: true })}
                                className={`w-full bg-white/5 border ${touched.name && !isNameValid ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-[#FF9D00]/50'} rounded-xl py-2.5 pl-10 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:ring-1 ${touched.name && !isNameValid ? 'focus:ring-red-500' : 'focus:ring-[#FF9D00]/50'} transition-all`}
                                placeholder="Steve Jobs"
                            />
                        </div>
                    </div>

                    <div className="space-y-1.5">
                        <label className="text-[13px] font-medium text-white/80 ml-1 block">Email address</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <Mail className={`w-4 h-4 ${touched.email && !isEmailValid ? 'text-red-400' : 'text-white/40'}`} />
                            </div>
                            <input
                                type="email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                onBlur={() => setTouched({ ...touched, email: true })}
                                className={`w-full bg-white/5 border ${touched.email && !isEmailValid ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-[#FF9D00]/50'} rounded-xl py-2.5 pl-10 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:ring-1 ${touched.email && !isEmailValid ? 'focus:ring-red-500' : 'focus:ring-[#FF9D00]/50'} transition-all`}
                                placeholder="name@company.com"
                            />
                        </div>
                        {touched.email && !isEmailValid && (
                            <p className="text-red-400 text-[12px] ml-1 mt-1">Please enter a valid email address.</p>
                        )}
                    </div>

                    <div className="space-y-1.5">
                        <label className="text-[13px] font-medium text-white/80 ml-1 block">Password</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <Lock className={`w-4 h-4 ${touched.password && !isPasswordValid ? 'text-red-400' : 'text-white/40'}`} />
                            </div>
                            <input
                                type="password"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                onBlur={() => setTouched({ ...touched, password: true })}
                                className={`w-full bg-white/5 border ${touched.password && !isPasswordValid ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-[#FF9D00]/50'} rounded-xl py-2.5 pl-10 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:ring-1 ${touched.password && !isPasswordValid ? 'focus:ring-red-500' : 'focus:ring-[#FF9D00]/50'} transition-all`}
                                placeholder="Min. 8 characters"
                            />
                        </div>
                    </div>

                    <div className="space-y-1.5">
                        <label className="text-[13px] font-medium text-white/80 ml-1 block">Confirm Password</label>
                        <div className="relative">
                            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                                <Lock className={`w-4 h-4 ${touched.confirmPassword && !isConfirmPasswordValid ? 'text-red-400' : 'text-white/40'}`} />
                            </div>
                            <input
                                type="password"
                                value={confirmPassword}
                                onChange={(e) => setConfirmPassword(e.target.value)}
                                onBlur={() => setTouched({ ...touched, confirmPassword: true })}
                                className={`w-full bg-white/5 border ${touched.confirmPassword && !isConfirmPasswordValid ? 'border-red-500/50 focus:border-red-500' : 'border-white/10 focus:border-[#FF9D00]/50'} rounded-xl py-2.5 pl-10 pr-4 text-white placeholder:text-white/20 focus:outline-none focus:ring-1 ${touched.confirmPassword && !isConfirmPasswordValid ? 'focus:ring-red-500' : 'focus:ring-[#FF9D00]/50'} transition-all`}
                                placeholder="Match your password"
                            />
                        </div>
                        {touched.confirmPassword && !isConfirmPasswordValid && confirmPassword.length > 0 && (
                            <p className="text-red-400 text-[12px] ml-1 mt-1">Passwords do not match.</p>
                        )}
                    </div>

                    <button
                        type="submit"
                        disabled={!isFormValid}
                        className={`w-full group flex items-center justify-center gap-2 py-3 mt-4 rounded-xl font-medium transition-all duration-300 ${
                            isFormValid 
                            ? 'bg-white text-black hover:bg-[#FF9D00] hover:scale-[1.02]' 
                            : 'bg-white/10 text-white/30 cursor-not-allowed'
                        }`}
                    >
                        <span>Create Account</span>
                        <ArrowRight className={`w-4 h-4 transition-transform duration-300 ${isFormValid ? 'group-hover:translate-x-1' : ''}`} />
                    </button>
                    
                    <button
                        type="button"
                        className="w-full flex items-center justify-center gap-3 py-3 rounded-xl bg-white/5 border border-white/10 text-white hover:bg-white/10 transition-colors duration-200 mt-3"
                    >
                        <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                            <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                            <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05"/>
                            <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
                        </svg>
                        <span className="text-[14px] font-medium">Google</span>
                    </button>
                </form>

                <p className="mt-8 text-center text-[14px] text-white/50">
                    Already have an account?{' '}
                    <button onClick={openSignIn} className="text-[#FF9D00] hover:text-[#FF9D00]/80 font-medium transition-colors">
                        Sign In
                    </button>
                </p>
            </div>
        </div>
    );
}
