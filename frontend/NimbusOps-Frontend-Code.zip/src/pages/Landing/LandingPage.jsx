import { useEffect, useRef } from "react";
import gsap from "gsap";
import ScrollTrigger from "gsap/ScrollTrigger";

import FrameSequence from "../../components/landing/FrameSequence";
import Hero from "../../components/landing/Hero";
import FeaturePrediction from "../../components/landing/FeaturePrediction";
import Scene3 from "../../components/landing/Scene3";

gsap.registerPlugin(ScrollTrigger);

export default function LandingPage() {
    const containerRef = useRef(null);

    useEffect(() => {
        const ctx = gsap.context(() => {
            // Initial state for scenes that enter later
            gsap.set(".prediction", { autoAlpha: 0, y: 40 });
            gsap.set(".scene-3", { autoAlpha: 0, y: 40 });

            gsap.set(".architecture-card", { autoAlpha: 0, y: 40 });
            gsap.set(".icon-glow", { opacity: 0 });

            // Master timeline to orchestrate DOM elements synced with scroll
            // Using relative chaining allows GSAP to automatically distribute
            // the total duration evenly across the 700vh scroll container.
            const tl = gsap.timeline({
                scrollTrigger: {
                    trigger: containerRef.current,
                    start: "top top",
                    end: "bottom bottom",
                    scrub: 1,
                }
            });
            
            tl.to(".hero", { autoAlpha: 0, y: -40, duration: 1 })
              .to(".prediction", { autoAlpha: 1, y: 0, duration: 1 })
              .to(".prediction", { autoAlpha: 1, duration: 2 }) // hold
              .to(".prediction", { autoAlpha: 0, y: -40, duration: 1 })
              .to(".scene-3", { autoAlpha: 1, y: 0, duration: 1 })
              .to(".architecture-card", { autoAlpha: 1, y: 0, duration: 1, stagger: 0.2 })
              .to(".pipeline-line", { x: "0%", duration: 1, ease: "power1.inOut" })
              .to(".pipeline-line-mobile", { y: "0%", duration: 1, ease: "power1.inOut" }, "<")
              .to(".icon-glow", { opacity: 1, duration: 1, stagger: 0.2 })
              .to(".scene-3", { autoAlpha: 1, duration: 2 }) // hold
              .to(".scene-3", { autoAlpha: 0, y: -40, duration: 1 });

        }, containerRef);

        return () => ctx.revert();
    }, []);

    return (
        <div
            id="landing"
            ref={containerRef}
            className="relative h-[700vh]"
        >
            <FrameSequence />
            <Hero />
            <FeaturePrediction />
            <Scene3 />
        </div>
    );
}