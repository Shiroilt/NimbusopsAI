import { createContext, useContext, useState, useCallback } from "react";

const AuthContext = createContext();

export function AuthProvider({ children }) {
    const [authMode, setAuthMode] = useState("closed"); // 'closed' | 'signin' | 'signup'

    const openSignIn = useCallback(() => setAuthMode("signin"), []);
    const openSignUp = useCallback(() => setAuthMode("signup"), []);
    const closeAuth = useCallback(() => setAuthMode("closed"), []);

    return (
        <AuthContext.Provider value={{ authMode, openSignIn, openSignUp, closeAuth }}>
            {children}
        </AuthContext.Provider>
    );
}

export function useAuth() {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error("useAuth must be used within an AuthProvider");
    }
    return context;
}
