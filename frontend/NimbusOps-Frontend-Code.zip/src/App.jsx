import LandingLayout from "./layouts/LandingLayout";
import { AuthProvider } from "./context/AuthContext";
import AuthModal from "./components/auth/AuthModal";

function App() {
  return (
    <AuthProvider>
      <LandingLayout />
      <AuthModal />
    </AuthProvider>
  );
}

export default App;